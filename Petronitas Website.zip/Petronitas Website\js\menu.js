/* ===========================================================================
   Petronita's, Southern & Latin Cuisine
   menu.js, THE ONE FILE YOU EDIT TO CHANGE THE MENU
   ---------------------------------------------------------------------------
   Every course, description, price and detail below was transcribed from
   Petronita's own PDF menus and their website. Nothing here is invented.
   Change something once, here, then rebuild (see README) and it updates on
   the menu page AND on the homepage, because both read this same list. They
   can never drift apart.

   ITEM FIELDS
     name    as it reads on the printed menu
     desc    the small line underneath. Optional.
     price   the number only, as a string: '20'. Leave it off entirely for
             the tasting menus, which are priced as a whole, not per course.
     star    true pulls the course onto the homepage as a signature card.
     v       true marks the item vegan, which drives the legend.

   SECTION FIELDS
     accent  'gold' | 'ember' | 'jade'
             The three accents rotate down the menu page, the way the
             candlelight, the fire and the herbs run through the food.
     note    small print under the heading, e.g. the vegan line.
     kind    'food' | 'drink'. Only used for the legend and the chips.
   =========================================================================== */

var MENU = [
  {
    id: 'tasting',
    name: "Chef's Tasting Menu",
    es: 'Menú de Degustación',
    accent: 'gold',
    kind: 'food',
    blurb: 'Five courses, served in order, changing with the season. This is ' +
           'the dinner service in full.',
    note: 'August / September 2026',
    items: [
      { name: 'Watermelon Shrimp Ceviche', desc: 'Watermelon, red onion, jalapeño, cilantro, mint', star: true },
      { name: 'Citrus Carpaccio', desc: 'Blood orange, navel orange, red onion, fennel, kalamata olive, cotija, arugula, extra virgin olive oil' },
      { name: 'Duck Tostada', desc: 'Hibiscus tortilla, black bean purée, cherry rum glaze', star: true },
      { name: 'Braised Short Rib', desc: 'Celery root purée, Aleppo pepper demi glace, pomegranate chimichurri', star: true },
      { name: 'Tres Leches Bread Pudding', desc: 'Crème anglaise, seasonal berries, mint', star: true }
    ]
  },
  {
    id: 'tasting-vegan',
    name: "Chef's Tasting Menu, Vegan",
    es: 'Menú Vegano',
    accent: 'jade',
    kind: 'food',
    blurb: 'The same five courses, built without any animal product. Ordered ' +
           'the same way, served the same night.',
    note: 'August / September 2026',
    items: [
      { name: 'Watermelon Ceviche', desc: 'Watermelon, red onion, jalapeño, cilantro, mint', v: true },
      { name: 'Citrus Carpaccio', desc: 'Blood orange, navel orange, red onion, fennel, kalamata olive, arugula, extra virgin olive oil', v: true },
      { name: 'Chanterelle Tostada', desc: 'Hibiscus tortilla, candied chanterelle, black bean purée, cherry rum glaze', v: true },
      { name: 'Ancho Agave Cauliflower Steak', desc: 'Pomegranate chimichurri, portabella, vegetable demi glace', v: true },
      { name: 'Mango Chili Lime Sorbet', v: true }
    ]
  },
  {
    id: 'brunch',
    name: 'Brunch',
    es: 'Almuerzo',
    accent: 'ember',
    kind: 'food',
    blurb: 'Saturday and Sunday, ten until three. Southern plates with the ' +
           'Latin side of the kitchen showing.',
    items: [
      { name: 'Shrimp & Gouda Grits', price: '20', desc: 'Cream-soaked gouda grits, sautéed shrimp, pan sauce, chef’s garnish', star: true },
      { name: 'Chicken & Waffles', price: '20', desc: 'Crisp fried chicken, buttermilk waffles, spiced maple cream, chef’s buffalo sauce, powdered sugar' },
      { name: 'Cuban Breakfast Skillet', price: '22', desc: 'Mojo-roasted beef, breakfast potatoes, black bean purée, two eggs, bright pomegranate chimichurri, toasted Cuban bread. Confit portabella mushroom or tofu available' },
      { name: 'Brûlée French Toast', price: '18', desc: 'Caramelized French toast, cinnamon brown butter, fresh berries, spiced maple cream' }
    ]
  },
  {
    id: 'sides',
    name: 'Accompaniments',
    es: 'Acompañamientos',
    accent: 'ember',
    kind: 'food',
    blurb: 'Add to any brunch plate.',
    items: [
      { name: 'Breakfast Potatoes', price: '6' },
      { name: 'Gouda Grits', price: '6' },
      { name: 'Two Eggs', price: '5' }
    ]
  },
  {
    id: 'cocktails-dinner',
    name: 'Dinner Cocktails',
    es: 'Cócteles',
    accent: 'gold',
    kind: 'drink',
    blurb: 'Built on sake rather than spirits, which keeps them light enough ' +
           'to sit through five courses.',
    items: [
      { name: 'Springfield Fizz', desc: 'Junmai Ginjo sake, exotic guava and vibrant yuzu, softened with golden honey and fresh mint', star: true },
      { name: 'Tamarind Blossom', desc: 'Junmai Ginjo sake, tamarind and delicate lychee, fresh lime and elderflower liqueur, Tajín-kissed rim' },
      { name: 'Southern Sunrise', desc: 'Nigori sake and ripe mango, vibrant yuzu, ginger liqueur' },
      { name: 'Magnolia Spritz', desc: 'Junmai Ginjo sake, pineapple and aromatic Thai basil, fresh lime, crisp Prosecco' }
    ]
  },
  {
    id: 'cocktails-brunch',
    name: 'Brunch Cocktails',
    es: 'Cócteles de Almuerzo',
    accent: 'jade',
    kind: 'drink',
    blurb: 'Saturday and Sunday only, alongside the brunch plates.',
    items: [
      { name: 'Calypso Bloom', desc: 'Petronita’s take on a traditional Aperol spritz' },
      { name: 'Garden District Mimosa & Historic District Flight', desc: 'Available by the glass or as a curated tasting flight' },
      { name: 'The Cafe Petronita', desc: 'Our house espresso martini' },
      { name: 'Petronita’s Signature Sangria', desc: 'Available in white or red. A nod to our Latin roots' }
    ]
  }
];

/* Photographs we actually hold. A course only becomes a homepage card if it
   has a picture, so this map is what decides. Add a file here and the card
   appears on the next build. */
var SIGNATURE_PHOTOS = {};

/* Every detail of the restaurant, stated once and read everywhere: the header,
   all four page footers, the structured data and the open/closed indicator. */
var SHOP = {
  name:      "Petronita's",
  full:      "Petronita's Southern & Latin Cuisine",
  tagline:   'Southern & Latin Cuisine, Elevated',
  motto:     'A nocturnal tribute to soul, spice and silver smoke, served under candlelight.',
  kind:      'Southern & Latin · Tasting Menu',
  est:       '2026',

  phone:     '(904) 465-6568',
  phoneHref: '+19044656568',
  email:     'reserve@petronitas.com',

  street:    '1349 N. Market Street',
  city:      'Jacksonville, FL 32206',
  district:  'Historic Springfield',
  /* No lat/lng on purpose. The map link searches the written address instead,
     which is always right, where a hand-typed coordinate can quietly be wrong. */
  mapsUrl:   'https://www.google.com/maps/search/?api=1&query=1349+N+Market+Street+Jacksonville+FL+32206',

  site:      'petronitas.com',
  instagram: 'https://www.instagram.com/petronitasjax',
  facebook:  'https://www.facebook.com/petronitasjax',
  tiktok:    'https://www.tiktok.com/@petronitasjax',
  handle:    '@petronitasjax',

  /* ---------------------------------------------------------------------
     RESERVATIONS

     This is the OpenTable address published on Petronita's own website. It
     is a plain profile link: it carries no restref and no ot_source, which
     means OpenTable counts these covers as network-sourced and bills the
     restaurant a per-person cover fee on guests the website already brought
     in. If Petronita's can supply their DIRECT link from the OpenTable
     dashboard, the one carrying restref= and ot_source=Restaurant website,
     put it here and those same bookings become fee-free.

     This note is for whoever maintains the site, not copy for guests.
     --------------------------------------------------------------------- */
  opentable: {
    url: 'https://www.opentable.com/r/petronitas-jacksonville',
    direct: false
  },

  /* Close times past midnight are written as 24 or more, so a service that
     runs into the next day still compares correctly. day is 0 = Sunday. */
  hours: [
    { day: 'Sunday',    open: 10, close: 15, label: 'Brunch' },
    { day: 'Sunday',    open: 18, close: 23, label: 'Dinner' },
    { day: 'Wednesday', open: 18, close: 23, label: 'Dinner' },
    { day: 'Thursday',  open: 18, close: 23, label: 'Dinner' },
    { day: 'Friday',    open: 18, close: 23, label: 'Dinner' },
    { day: 'Saturday',  open: 10, close: 15, label: 'Brunch' },
    { day: 'Saturday',  open: 18, close: 23, label: 'Dinner' }
  ],
  hoursDinner: 'Wednesday to Sunday, 6 PM to 11 PM',
  hoursBrunch: 'Saturday and Sunday, 10 AM to 3 PM',
  closedNote:  'Closed Monday and Tuesday'
};

/* The words that run across the band under the hero. Decorative, and hidden
   from screen readers, so they carry no information that is not elsewhere. */
var TICKER = [
  'Soul', 'Spice', 'Gold', 'Candlelight', 'Fire', 'Smoke',
  'Southern', 'Latin', 'Springfield', 'Est. 2026'
];
