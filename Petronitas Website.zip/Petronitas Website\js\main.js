/* ===========================================================================
   Petronita's, main.js
   ---------------------------------------------------------------------------
   Everything here is progressive enhancement. The menu, the prices, the hours
   and the address are all written into the HTML at build time, so with
   JavaScript switched off the site is still complete and readable. This file
   only adds the sticky header, the mobile menu, the live open/closed dot, the
   menu filter and the ticker on top of it.

   Reads js/menu.js for MENU, SHOP and TICKER. Loaded after it, and every
   entry point checks that what it needs exists before touching the DOM, so a
   page with no menu list costs nothing.
   =========================================================================== */
(function () {
  'use strict';

  /* -------------------------------------------------------------- helpers */
  var $  = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  var reduced = window.matchMedia
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
    : false;

  /* Turn 18 into "6 PM" and 10.5 into "10:30 AM". */
  function clock(h) {
    var hh = Math.floor(h) % 24;
    var mm = Math.round((h - Math.floor(h)) * 60);
    var ap = hh >= 12 ? 'PM' : 'AM';
    var h12 = hh % 12; if (h12 === 0) { h12 = 12; }
    return h12 + (mm ? ':' + (mm < 10 ? '0' + mm : mm) : '') + ' ' + ap;
  }

  /* ================================================================ HEADER
     Adds .is-stuck once the page has moved, which shrinks the bar and drops a
     blurred background behind it. rAF-throttled, so a fast scroll on a slow
     machine cannot queue up hundreds of style writes. */
  (function header() {
    var head = $('#siteHead');
    if (!head) { return; }
    var ticking = false;

    function apply() {
      var y = window.pageYOffset || document.documentElement.scrollTop;
      head.classList.toggle('is-stuck', y > 24);
      ticking = false;
    }
    apply();
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(apply); }
    }, { passive: true });
  }());

  /* ============================================================ MOBILE NAV
     A slide-in sheet. Closes on Escape, on a click outside, and whenever a
     link inside it is followed, and it locks the page behind it so the body
     does not scroll under the open sheet. */
  (function mobileNav() {
    var burger = $('#burger');
    var nav = $('#nav');
    if (!burger || !nav) { return; }

    var scrim = document.createElement('div');
    scrim.className = 'nav-scrim';
    document.body.appendChild(scrim);

    function setOpen(open) {
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      nav.classList.toggle('is-open', open);
      scrim.classList.toggle('is-open', open);
      document.body.classList.toggle('nav-open', open);
      if (open) {
        var first = $('a', nav);
        if (first) { first.focus(); }
      }
    }

    burger.addEventListener('click', function () {
      setOpen(burger.getAttribute('aria-expanded') !== 'true');
    });
    scrim.addEventListener('click', function () { setOpen(false); });
    $$('a', nav).forEach(function (a) {
      a.addEventListener('click', function () { setOpen(false); });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && burger.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
        burger.focus();
      }
    });
    /* If the viewport grows past the breakpoint while the sheet is open, the
       sheet stops being a sheet, so reset it rather than leaving it stranded. */
    window.addEventListener('resize', function () {
      if (window.innerWidth > 960) { setOpen(false); }
    });
  }());

  /* ========================================================== OPEN / CLOSED
     Petronita's runs two services on some days, brunch and dinner, so the
     hours are a flat list of sessions rather than one span per day. A session
     closing after midnight would be written as 24 or more, and yesterday's
     session is checked first so a late night still reads as open. */
  function sessionsOn(dayIndex) {
    if (typeof SHOP === 'undefined' || !SHOP.hours) { return []; }
    var name = DAYS[((dayIndex % 7) + 7) % 7];
    return SHOP.hours.filter(function (h) { return h.day === name; })
                     .sort(function (a, b) { return a.open - b.open; });
  }

  function openState(now) {
    var day = now.getDay();
    var hourNow = now.getHours() + now.getMinutes() / 60;
    var i, s;

    /* Yesterday's session may still be running if it closes after midnight. */
    var yest = sessionsOn(day - 1);
    for (i = 0; i < yest.length; i++) {
      if (yest[i].close > 24 && hourNow < (yest[i].close - 24)) {
        return { open: true, until: yest[i].close - 24, label: yest[i].label };
      }
    }

    var today = sessionsOn(day);
    for (i = 0; i < today.length; i++) {
      s = today[i];
      if (hourNow >= s.open && hourNow < s.close) {
        return { open: true, until: s.close, label: s.label };
      }
    }
    /* Shut right now, but is there a later service today? */
    for (i = 0; i < today.length; i++) {
      if (hourNow < today[i].open) {
        return { open: false, opensAt: today[i].open, label: today[i].label, sameDay: true };
      }
    }
    /* Shut for the night. Find the next day that opens at all. */
    for (i = 1; i <= 7; i++) {
      var next = sessionsOn(day + i);
      if (next.length) {
        return { open: false, opensAt: next[0].open, label: next[0].label,
                 dayName: next[0].day, sameDay: false };
      }
    }
    return { open: false };
  }

  function stateText(st) {
    if (!st) { return ''; }
    if (st.open) { return 'Open now until ' + clock(st.until); }
    if (st.opensAt === undefined) { return 'Closed'; }
    if (st.sameDay) { return 'Opens today at ' + clock(st.opensAt); }
    return 'Opens ' + st.dayName + ' at ' + clock(st.opensAt);
  }

  (function status() {
    var nodes = $$('[data-status]');
    if (!nodes.length || typeof SHOP === 'undefined') { return; }

    function paint() {
      var st = openState(new Date());
      var txt = stateText(st);
      nodes.forEach(function (n) {
        n.classList.toggle('is-open', !!st.open);
        var label = $('[data-status-text]', n);
        if (label) { label.textContent = txt; } else { n.textContent = txt; }
      });
    }
    paint();
    /* Re-check every minute so a page left open overnight does not lie. */
    window.setInterval(paint, 60000);
  }());

  /* Marks the current day in the hours table on the Visit page. */
  (function today() {
    var rows = $$('[data-day]');
    if (!rows.length) { return; }
    var name = DAYS[new Date().getDay()];
    rows.forEach(function (r) {
      r.classList.toggle('is-today', r.getAttribute('data-day') === name);
    });
  }());

  /* =========================================================== MENU FILTER
     Rows and whole sections are hidden with the hidden attribute rather than
     being removed, so the markup the browser found on load is the markup that
     stays, and switching a filter off restores the page exactly. */
  (function menuFilter() {
    var root = $('#menuRoot');
    if (!root) { return; }

    var chips  = $$('.chip');
    var groups = $$('.mgroup', root);
    var items  = $$('.mitem', root);
    var find   = $('#menuFind');
    var count  = $('#menuCount');
    var empty  = $('#menuEmpty');

    var cat = 'all';

    function norm(s) { return (s || '').toLowerCase(); }

    function run() {
      var q = norm(find ? find.value : '').trim();
      var shown = 0;

      groups.forEach(function (g) {
        var inCat = (cat === 'all' ||
                     g.id === cat ||
                     g.getAttribute('data-kind') === cat);
        var vis = 0;

        $$('.mitem', g).forEach(function (it) {
          var hay = it.getAttribute('data-hay') || '';
          var hit = inCat && (!q || hay.indexOf(q) !== -1);
          it.hidden = !hit;
          if (hit) { vis++; }
        });

        /* A section with nothing left in it disappears entirely, heading,
           blurb, rule and all. */
        g.hidden = (vis === 0);
        shown += vis;
      });

      if (count) {
        count.textContent = shown === items.length
          ? items.length + ' items'
          : shown + ' of ' + items.length;
      }
      if (empty) { empty.hidden = (shown !== 0); }
    }

    chips.forEach(function (c) {
      c.addEventListener('click', function () {
        cat = c.getAttribute('data-cat') || 'all';
        chips.forEach(function (o) {
          o.setAttribute('aria-pressed', o === c ? 'true' : 'false');
        });
        run();
        /* Jump to the section so the click has a visible result even when it
           was below the fold. A kind filter and 'all' both stay put. */
        var g = document.getElementById(cat);
        if (cat !== 'all' && g) {
          var bar = $('.menubar');
          var head = $('#siteHead');
          var offset = (bar ? bar.offsetHeight : 0) + (head ? head.offsetHeight : 0) + 12;
          var y = g.getBoundingClientRect().top + (window.pageYOffset || 0) - offset;
          window.scrollTo({ top: y < 0 ? 0 : y, behavior: reduced ? 'auto' : 'smooth' });
        }
      });
    });

    if (find) {
      var t = null;
      find.addEventListener('input', function () {
        window.clearTimeout(t);
        t = window.setTimeout(run, 110);
      });
      /* Escape clears the box, which is what people expect of a search field. */
      find.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && find.value) {
          find.value = '';
          run();
          e.stopPropagation();
        }
      });
    }

    run();
  }());

  /* ================================================================ TICKER
     Built from TICKER in menu.js. Two identical sets side by side: the
     animation slides exactly one set width, so the seam is invisible and the
     loop never jumps. Decorative, so it is hidden from assistive tech. */
  (function ticker() {
    var host = $('#ticker');
    if (!host || typeof TICKER === 'undefined') { return; }

    var set = document.createElement('div');
    set.className = 'ticker__set';
    TICKER.forEach(function (word) {
      var s = document.createElement('span');
      s.textContent = word;
      set.appendChild(s);
    });

    var track = document.createElement('div');
    track.className = 'ticker__track';
    track.appendChild(set);
    track.appendChild(set.cloneNode(true));

    host.setAttribute('aria-hidden', 'true');
    host.innerHTML = '';
    host.appendChild(track);
  }());

  /* ================================================================ REVEAL
     Fades sections in as they arrive. If IntersectionObserver is missing,
     everything is simply shown, never left invisible. */
  (function reveal() {
    var nodes = $$('[data-in]');
    if (!nodes.length) { return; }

    if (reduced || !('IntersectionObserver' in window)) {
      nodes.forEach(function (n) { n.classList.add('is-in'); });
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('is-in');
          io.unobserve(e.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .08 });

    /* Anything already on screen is shown straight away rather than waiting on
       the observer. The observer's first callback is asynchronous, and for
       something above the fold that is a gamble worth not taking: if it does
       not fire, the element sits at opacity 0 and the visitor never sees it. */
    function fold() { return window.innerHeight || document.documentElement.clientHeight; }

    var pending = [];
    nodes.forEach(function (n) {
      if (n.getBoundingClientRect().top < fold() * .95) {
        n.classList.add('is-in');
      } else {
        pending.push(n);
        io.observe(n);
      }
    });

    /* A belt-and-braces sweep on scroll, doing the same job the observer does.
       This is not redundant paranoia: these pages hide most of their content at
       opacity 0 until it is revealed, so an observer that fails to fire does
       not cost an animation, it costs the page. The observer is still what
       normally does the work, and each node is only ever revealed once. */
    var ticking = false;
    function sweep() {
      ticking = false;
      var limit = fold() * .95;
      var still = [];
      for (var i = 0; i < pending.length; i++) {
        var n = pending[i];
        if (n.classList.contains('is-in')) { continue; }
        if (n.getBoundingClientRect().top < limit) {
          n.classList.add('is-in');
          io.unobserve(n);
        } else {
          still.push(n);
        }
      }
      pending = still;
      if (!pending.length) {
        window.removeEventListener('scroll', onScroll);
        window.removeEventListener('resize', onScroll);
      }
    }
    function onScroll() {
      if (!ticking) { ticking = true; window.requestAnimationFrame(sweep); }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
  }());

  /* ================================================================== MISC */
  (function year() {
    $$('[data-year]').forEach(function (n) { n.textContent = new Date().getFullYear(); });
  }());

}());
